package com.cts.pension.disbursement.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ApiModel(value = "Model object that stores the processPensionInput details.")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class ProcessPensionInput {
	
	@ApiModelProperty(notes = "aadharNumber of pensioner")
    private Long aadharNumber;
	
	@ApiModelProperty(notes = "pensionamount of pensioner")
    private double pensionAmount;
	
	@ApiModelProperty(notes = "bankcharge of pensioner")
    private double bankCharge;
}