insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (420559429029,'Parthik','1999-12-03','BSDPS1495K',29000,1200,'self','SBI',9029486523,'private');
insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (420559429031,'Karan','1999-01-04','SBIN0000388',29000,1200,'self','SBI',9029856585,'private');
insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (320559431029,'Jay','1999-06-13','SBIN0000116',27000,1000,'self','SBI',8130585625,'private');
--
insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (420555821047,'Vaibhav','1999-02-18','TYUO109874',30000,1500,'self','HSBC',7017582645,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (459625453645,'Anshuman','1999-06-14','SHTOC34253',35000,1500,'family','INDIAN BANK',7017456745,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (110034568622,'Yogesh','1999-12-30','HMPIO67182',50000,5000,'self','IOB',9627564534,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (110005635647,'Gaurav','1999-11-17','SHTOC34253',65000,8000,'self','Indian Bank',6396453455,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (675647365647,'Mukul','1998-10-13','SHTOC34253',70000,8000,'self','Indian Bank',6396434565,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (435423876757,'Ashish','1998-01-21','DFGYM14759',55000,2000,'self','HDFC',6394563835,'private');

--insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (654738376757,'Bhavesh','1998-02-23','GHFFM67983',78000,9000,'family','ICICI',8130674523,'private')

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (656756476757,'Shubham','1999-11-28','PCASD1234Q',27000,10000,'family','ICICI',8130234567,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (656456785634,'Gulshan','1999-09-21','PCQAZ1285Q',30000,12000,'family','SBI',6396235677,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (342567345637,'Akash','1998-01-24','PCSDZ1287G',40000,12002,'family','SBI',6396235677,'public');

--insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (342567345637,'Mukul','1998-11-05','GHFKJ67894',63000,9000,'self','KOTAK',9917658327,'public')

--insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (342567345637,'Abhishek','1999-12-03','MKUIO12345',100000,5000,'self','central bank',9917452377,'public')

--insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (1234567657,'Ankit','1999-02-18','TYUOIO9874',98000,5500,'self','HSBC',9917345647,'public')

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (123456765765,'Kartik','1998-12-05','GHFFM67983',55000,2000,'family','ICICI',7340656756,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (140023455765,'Shresth','1999-05-22','SHTOC34253',65000,8000,'family','HDFC',9917456756,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (785647376767,'Akshay','1999-04-23','TYUO109874',26000,1000,'self','HSBC',7017653423,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (120034523767,'Harshit','1998-07-15','BHMER12436',29500,1100,'self','HDFC',7017653423,'private');