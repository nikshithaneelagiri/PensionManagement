package com.cts.pension.process.exception;

@SuppressWarnings("serial")
public class AuthorizationException extends Exception{

	public AuthorizationException(String message) {
		super(message);
	}
}
