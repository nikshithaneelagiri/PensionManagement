package com.cts.pension.process.model;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ApiModel(value = "Model object that stores the pensioner details.")
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class PensionerDetail {
	
	@ApiModelProperty(notes = "aadharNumber of pensioner")
	private long aadharNumber;
	
	@ApiModelProperty(notes = "name of pensioner")
	private String name;
	
	@ApiModelProperty(notes = "dateofbirth of pensioner")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateOfBirth;
	
	@ApiModelProperty(notes = "panNumber of pensioner")
	private String pan;
	
	@ApiModelProperty(notes = "salary earned by pensioner")
	private double salaryEarned;
	
	@ApiModelProperty(notes = "allowances of pensioner")
	private double allowances;
	
	@ApiModelProperty(notes = "pensiontype of pensioner")
	private String pensionType;
	
	@ApiModelProperty(notes = "bankname of pensioner")
	private String bankName;
	
	@ApiModelProperty(notes = "accountnumber of pensioner")
	private String accountNumber;
	
	@ApiModelProperty(notes = "bankType of pensioner")
	private String bankType;
	
}
